import React from 'react';
import { Link } from 'react-router-dom';

const SocialIcon = ({ href, children }: { href: string, children: React.ReactNode }) => (
  <a href={href} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-emerald-400 transition-colors">
    {children}
  </a>
);

const FooterLink = ({ to, children }: { to: string, children: React.ReactNode }) => (
    <Link to={to} className="hover:text-transparent hover:bg-clip-text hover:bg-gradient-to-r hover:from-emerald-400 hover:to-sky-400 transition-colors">{children}</Link>
);

const Footer: React.FC = () => {
  return (
    <footer className="bg-zinc-900 border-t border-zinc-800">
      <div className="container mx-auto px-4 md:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
          <div className="col-span-2 lg:col-span-1">
            <h2 className="mb-4 text-lg font-bold text-slate-100">Quantum<span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-sky-400">Leads</span></h2>
            <p className="text-slate-400 text-sm">High Quality USA Leads.</p>
            <div className="flex space-x-4 mt-4">
              <SocialIcon href="#"><svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M22.46,6C21.69,6.35 20.86,6.58 20,6.69C20.88,6.16 21.56,5.32 21.88,4.31C21.05,4.81 20.13,5.16 19.16,5.36C18.37,4.5 17.26,4 16,4C13.65,4 11.73,5.92 11.73,8.29C11.73,8.63 11.77,8.96 11.84,9.27C8.28,9.09 5.11,7.38 3,4.79C2.63,5.42 2.42,6.16 2.42,6.94C2.42,8.43 3.17,9.75 4.33,10.5C3.62,10.5 2.96,10.3 2.38,10C2.38,10 2.38,10 2.38,10.03C2.38,12.11 3.86,13.85 5.82,14.24C5.46,14.34 5.08,14.39 4.69,14.39C4.42,14.39 4.15,14.36 3.89,14.31C4.43,16.02 6.13,17.26 8.13,17.29C6.67,18.45 4.82,19.14 2.83,19.14C2.5,19.14 2.17,19.12 1.85,19.08C3.85,20.33 6.16,21.08 8.67,21.08C16,21.08 20.34,14.88 20.34,9.23C20.34,9.04 20.34,8.84 20.33,8.65C21.14,8.06 21.86,7.1 22.46,6Z" /></svg></SocialIcon>
              <SocialIcon href="#"><svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878V14.89h-2.89v-3.42h2.89v-2.607c0-2.867 1.719-4.448 4.316-4.448 1.242 0 2.5 0.224 2.5 0.224v2.89h-1.45c-1.43 0-1.87.894-1.87 1.777v2.13h3.21l-.51 3.42h-2.7v7.22C18.343 21.128 22 16.991 22 12z" /></svg></SocialIcon>
              <SocialIcon href="#"><svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.85s-.011 3.584-.069 4.85c-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07s-3.584-.012-4.85-.07c-3.252-.148-4.771-1.691-4.919-4.919-.058-1.265-.069-1.645-.069-4.85s.011-3.584.069-4.85c.149-3.225 1.664-4.771 4.919-4.919C8.416 2.175 8.796 2.163 12 2.163m0-2.163C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12s.014 3.667.072 4.947c.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24s3.667-.014 4.947-.072c4.358-.2 6.78-2.618 6.98-6.98.058-1.28.072-1.689.072-4.948s-.014-3.667-.072-4.947c-.2-4.358-2.618-6.78-6.98-6.98C15.667.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zm0 10.162a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.88 1.44 1.44 0 000-2.88z" /></svg></SocialIcon>
              <SocialIcon href="#"><svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M19,3A2,2 0 0,1 21,5V19A2,2 0 0,1 19,21H5A2,2 0 0,1 3,19V5A2,2 0 0,1 5,3H19M18.5,18.5V13.2A3.26,3.26 0 0,0 15.24,9.94C14.39,9.94 13.4,10.43 13,11.11V10.28H10.13V18.5H13V13.57C13,12.8 13.44,12.27 14.15,12.27C14.85,12.27 15.24,12.8 15.24,13.57V18.5H18.5M6.88,8.56A1.68,1.68 0 0,0 8.56,6.88C8.56,6 8,5.12 6.88,5.12C5.76,5.12 5.12,6 5.12,6.88A1.68,1.68 0 0,0 6.88,8.56M8.27,18.5V10.28H5.5V18.5H8.27Z" /></svg></SocialIcon>
            </div>
          </div>
          <div>
            <h3 className="mb-4 font-semibold text-slate-100">Services</h3>
            <ul className="text-slate-400 space-y-2 text-sm">
              <li><FooterLink to="/service-details#inbound-calls">Inbound Calls</FooterLink></li>
              <li><FooterLink to="/service-details#exclusive-leads">Exclusive Leads</FooterLink></li>
              <li><FooterLink to="/service-details#pay-per-lead-campaigns">Pay Per Lead</FooterLink></li>
              <li><FooterLink to="/service-details#custom-campaigns">Custom Campaigns</FooterLink></li>
            </ul>
          </div>
           <div>
            <h3 className="mb-4 font-semibold text-slate-100">Company</h3>
            <ul className="text-slate-400 space-y-2 text-sm">
              <li><FooterLink to="/about#our-journey">About Us</FooterLink></li>
              <li><FooterLink to="/why-us">Why Choose Us</FooterLink></li>
              <li><FooterLink to="/contact">Contact</FooterLink></li>
            </ul>
          </div>
          <div>
            <h3 className="mb-4 font-semibold text-slate-100">Contact</h3>
            <ul className="text-slate-400 space-y-2 text-sm">
              <li className="flex items-center space-x-2"><span>Email:</span> <a href="mailto:contact@quantumleads.com" className="hover:text-transparent hover:bg-clip-text hover:bg-gradient-to-r hover:from-emerald-400 hover:to-sky-400 transition-colors">contact@quantumleads.com</a></li>
              <li className="flex items-center space-x-2"><span>Phone:</span> <a href="tel:+1234567890" className="hover:text-transparent hover:bg-clip-text hover:bg-gradient-to-r hover:from-emerald-400 hover:to-sky-400 transition-colors">+1 (234) 567-890</a></li>
               <li className="flex items-center space-x-2"><span>WhatsApp:</span> <a href="https://wa.me/1234567890" className="hover:text-transparent hover:bg-clip-text hover:bg-gradient-to-r hover:from-emerald-400 hover:to-sky-400 transition-colors">+1 (234) 567-890</a></li>
            </ul>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-zinc-800 text-center text-slate-400 text-sm">
          <p>&copy; {new Date().getFullYear()} QuantumLeads. All Rights Reserved. UK Registered Company.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;