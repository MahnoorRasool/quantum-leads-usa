import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { NAV_LINKS } from '../constants';
import type { NavLink as NavLinkType } from '../constants';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const linkClasses = ({ isActive }: { isActive: boolean }): string => 
    `block py-2 px-3 rounded md:p-0 transition-colors duration-300 ${
      isActive 
      ? 'text-white font-semibold bg-zinc-700 md:bg-transparent' 
      : 'text-slate-400 hover:bg-zinc-800 md:hover:bg-transparent md:hover:text-white'
    }`;

  return (
    <header className="sticky top-0 z-50 bg-zinc-900/80 backdrop-blur-lg border-b border-zinc-800/80">
      <nav className="container mx-auto px-4 md:px-8">
        <div className="flex flex-wrap items-center justify-between mx-auto py-4">
          <Link to="/" className="flex items-center space-x-3 rtl:space-x-reverse">
            <span className="self-center text-2xl font-bold whitespace-nowrap text-slate-100">Quantum<span className="text-transparent bg-clip-text bg-gradient-to-r from-green-400 via-emerald-500 to-sky-400 animate-gradient">Leads</span></span>
          </Link>
          <div className="flex items-center md:order-2 space-x-3 md:space-x-2 rtl:space-x-reverse">
             <Link to="/login">
              <button type="button" className="text-white bg-transparent hover:bg-zinc-800 focus:ring-4 focus:outline-none focus:ring-zinc-700 font-semibold rounded-lg text-sm px-5 py-2.5 text-center transition-all duration-300 transform hover:scale-105 border border-zinc-700">
                Login
              </button>
            </Link>
            <Link to="/contact">
              <button type="button" className="text-white bg-gradient-to-r from-green-400 via-emerald-500 to-sky-500 animate-gradient focus:ring-4 focus:outline-none focus:ring-emerald-300 font-semibold rounded-lg text-sm px-5 py-2.5 text-center transition-all duration-300 transform hover:scale-105 shadow-lg shadow-emerald-500/10">
                Contact Us
              </button>
            </Link>
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              type="button" 
              className="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-slate-400 rounded-lg md:hidden hover:bg-zinc-800 focus:outline-none focus:ring-2 focus:ring-zinc-700" 
              aria-controls="navbar-sticky" 
              aria-expanded={isMenuOpen}>
              <span className="sr-only">Open main menu</span>
              <svg className="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
                  <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M1 1h15M1 7h15M1 13h15"/>
              </svg>
            </button>
          </div>
          <div className={`items-center justify-between w-full md:flex md:w-auto md:order-1 ${isMenuOpen ? 'block' : 'hidden'}`} id="navbar-sticky">
            <ul className="flex flex-col p-4 md:p-0 mt-4 font-medium border border-zinc-700 rounded-lg bg-zinc-900 md:bg-transparent md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0">
              {NAV_LINKS.map((link: NavLinkType) => (
                <li key={link.name}>
                  <NavLink to={link.path} className={linkClasses} end>
                    {link.name}
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Header;