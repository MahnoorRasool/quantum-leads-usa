import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';

interface AnimateOnScrollProps {
    children: React.ReactNode;
    className?: string;
    animation?: 'fade-in-up' | 'fade-in-down' | 'fade-in-left' | 'fade-in-right' | 'zoom-in';
    delay?: number;
    as?: React.ElementType;
}

const AnimateOnScroll: React.FC<AnimateOnScrollProps> = ({
    children,
    className = '',
    animation = 'fade-in-up',
    delay = 0,
    as: Tag = 'div',
}) => {
    const ref = useRef<HTMLElement>(null);
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    setIsVisible(true);
                    observer.unobserve(entry.target);
                }
            },
            { threshold: 0.1 }
        );

        const currentRef = ref.current;
        if (currentRef) {
            observer.observe(currentRef);
        }

        return () => {
            if (currentRef) {
                observer.unobserve(currentRef);
            }
        };
    }, []);

    const combinedClassName = `scroll-animate ${animation} ${isVisible ? 'is-visible' : ''} ${className}`;

    return (
        <Tag
            ref={ref}
            className={combinedClassName}
            style={{ transitionDelay: `${delay}ms` }}
        >
            {children}
        </Tag>
    );
};

const getIconColorClass = (index: number) => {
    const colors = [
        'bg-gradient-to-br from-emerald-500 to-sky-500 text-white',
        'bg-gradient-to-br from-sky-500 to-teal-500 text-white',
        'bg-gradient-to-br from-green-500 to-emerald-500 text-white',
    ];
    return colors[index % colors.length];
};

const FeatureItem = ({ icon, title, description, index }: { icon: React.ReactNode, title: string, description: string, index: number }) => (
    <div className="flex items-start space-x-4">
        <div className={`flex-shrink-0 w-12 h-12 rounded-lg ${getIconColorClass(index)} flex items-center justify-center`}>
            {icon}
        </div>
        <div>
            <h3 className="text-lg font-semibold text-slate-100">{title}</h3>
            <p className="text-slate-400">{description}</p>
        </div>
    </div>
);

const AnimatedStatItem = ({ value, label }: { value: string; label: string }) => {
    const [displayValue, setDisplayValue] = useState('0');
    const ref = useRef<HTMLDivElement>(null);
    const hasAnimated = useRef(false);

    const numberMatch = value.match(/[\d.]+/);
    const endValue = numberMatch ? parseFloat(numberMatch[0]) : 0;
    const suffix = numberMatch ? value.substring(numberMatch[0].length) : '';

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting && !hasAnimated.current) {
                    hasAnimated.current = true;
                    
                    let startTimestamp: number | null = null;
                    const duration = 2000;

                    const step = (timestamp: number) => {
                        if (!startTimestamp) startTimestamp = timestamp;
                        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
                        const currentNum = progress * endValue;
                        
                        const isDecimal = String(endValue).includes('.');
                        const finalDisplay = isDecimal ? currentNum.toFixed(1) : Math.floor(currentNum).toLocaleString();

                        if (progress < 1) {
                            setDisplayValue(finalDisplay);
                            window.requestAnimationFrame(step);
                        } else {
                            setDisplayValue(String(endValue).toLocaleString());
                        }
                    };
                    window.requestAnimationFrame(step);
                }
            },
            { threshold: 0.5 }
        );

        const currentRef = ref.current;
        if (currentRef) observer.observe(currentRef);
        return () => { if (currentRef) observer.unobserve(currentRef); };
    }, [endValue]);

    return (
        <div className="text-center group" ref={ref}>
            <p className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-sky-400 transition-all duration-300 group-hover:from-emerald-300 group-hover:to-sky-300 group-hover:drop-shadow-[0_0_10px_rgba(52,211,153,0.5)]">
                {displayValue}{suffix}
            </p>
            <p className="text-slate-400 mt-2 transition-colors duration-300 group-hover:text-slate-300">{label}</p>
        </div>
    );
};

const GlassCard = ({ children, className = '' }: { children: React.ReactNode; className?: string }) => {
    const cardRef = useRef<HTMLDivElement>(null);

    const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
        if (!cardRef.current) return;
        const rect = cardRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        cardRef.current.style.setProperty('--mouse-x', `${x}px`);
        cardRef.current.style.setProperty('--mouse-y', `${y}px`);
    };

    return (
        <div 
            ref={cardRef}
            onMouseMove={handleMouseMove}
            className={`glass-card-interactive bg-zinc-800/50 backdrop-blur-lg border border-zinc-700/50 rounded-2xl shadow-lg shadow-black/20 transition-all duration-300 h-full overflow-hidden ${className}`}
        >
            <div className="relative z-10 h-full">
                {children}
            </div>
        </div>
    );
};


const HomePage: React.FC = () => {
    const features = [
      {
        icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>,
        title: "Targeted Discovery",
        description: "We analyze your ideal customer profile for precise campaign targeting.",
      },
      {
        icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>,
        title: "Verified Leads",
        description: "Every lead is scrubbed and verified to ensure high intent and quality.",
      },
      {
        icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V7a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>,
        title: "Transparent Reporting",
        description: "Real-time dashboards provide a clear view of your campaign's performance.",
      }
    ];

    const processSteps = [
      {
        icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>,
        title: "01. Discovery",
        description: "We discuss your target audience and campaign goals to create a tailored strategy.",
      },
      {
        icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 16v-2m0-10v2m0 6v2m-6-4h2m10 0h2m-5-10v2m0 16v-2M8 8l2 2m6 6l2 2M8 16l2-2m6-6l2-2" /></svg>,
        title: "02. Lead Generation",
        description: "Our team launches the campaign, generating exclusive, real-time leads for your business.",
      },
      {
        icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
        title: "03. Delivery & Reporting",
        description: "Verified leads are delivered directly to you, with transparent reporting to track ROI.",
      }
    ];

    const testimonials = [
      {
        quote: "QuantumLeads transformed our sales pipeline. The quality of leads is unmatched, and the real-time delivery has been a game-changer for our team.",
        name: "Sarah Johnson",
        title: "Marketing Director, Growth Co.",
        image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=160&h=150&dpr=2",
        rating: 5,
      },
      {
        quote: "The pay-per-lead model is fantastic. We only pay for results, and the results have been incredible. Our ROI has increased by over 40% since partnering with them.",
        name: "Michael Chen",
        title: "CEO, Innovate Solutions",
        image: "https://images.pexels.com/photos/1043473/pexels-photo-1043473.jpeg?auto=compress&cs=tinysrgb&w=160&h=150&dpr=2",
        rating: 5,
      },
      {
        quote: "Their team is incredibly responsive and knowledgeable. They took the time to understand our niche and delivered leads that were a perfect fit. Highly recommend!",
        name: "Jessica Williams",
        title: "Founder, Tech Startup",
        image: "https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=160&h=150&dpr=2",
        rating: 5,
      }
    ];

    const [activeTestimonial, setActiveTestimonial] = useState(0);

    useEffect(() => {
        const timer = setInterval(() => {
            setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
        }, 5000); // Change slide every 5 seconds

        return () => clearInterval(timer);
    }, [testimonials.length]);

    const nextTestimonial = () => {
        setActiveTestimonial(prev => (prev + 1) % testimonials.length);
    };

    const prevTestimonial = () => {
        setActiveTestimonial(prev => (prev - 1 + testimonials.length) % testimonials.length);
    };
    
    const StarIcon = () => (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
    );


  return (
    <div className="space-y-24 md:space-y-32">
        {/* Hero Section */}
        <section className="relative py-20 md:py-28 text-center overflow-hidden">
            <div 
                aria-hidden="true" 
                className="absolute inset-0 -z-20 bg-cover bg-center" 
                style={{ backgroundImage: "url('https://media.istockphoto.com/id/1263517739/photo/creative-image-of-many-business-people-conference-group-meeting.jpg?s=612x612&w=0&k=20&c=b3UJfsNcG1j9husTpA7d8QagjAr9SbPI5m9ADzTth50=')" }}
            ></div>
            <div aria-hidden="true" className="absolute inset-0 -z-10 bg-zinc-900/70"></div>
            <div aria-hidden="true" className="absolute inset-0 -z-10 opacity-20">
                <div className="absolute top-[10%] left-[15%] w-48 h-48 bg-emerald-600 rounded-full filter blur-3xl float-1"></div>
                <div className="absolute bottom-[10%] right-[15%] w-40 h-40 bg-sky-600 rounded-full filter blur-3xl float-3"></div>
            </div>
            <div className="container mx-auto px-4 md:px-8">
                <AnimateOnScroll animation="fade-in-down">
                  <div className="inline-block bg-emerald-900/50 text-emerald-300 text-sm font-semibold px-4 py-1.5 rounded-md mb-6 border border-emerald-800">
                      <span>UK Registered • US Market Leaders</span>
                  </div>
                  <h1 className="text-5xl sm:text-6xl md:text-7xl font-extrabold text-slate-100 leading-tight my-4 max-w-4xl mx-auto">
                      Connecting Advertisers with <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-sky-500">Real Customers</span>
                  </h1>
                  <p className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto mb-8">
                      We generate and deliver verified leads that help your business grow. Partner with us for consistent, targeted, and profitable customer acquisition.
                  </p>
                  <div className="flex flex-wrap gap-4 justify-center">
                    <Link to="/contact">
                        <button className="bg-gradient-to-r from-green-400 via-emerald-500 to-sky-500 animate-gradient text-white font-semibold py-3 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg shadow-emerald-500/10">
                            Get Started
                        </button>
                    </Link>
                    <Link to="/services">
                        <button className="bg-transparent text-white font-semibold py-3 px-8 rounded-lg hover:bg-zinc-800 transition-all duration-300 border border-zinc-700">
                            Our Services
                        </button>
                    </Link>
                  </div>
                </AnimateOnScroll>
            </div>
        </section>

      {/* Trusted By Section */}
       <section className="py-12 container mx-auto px-4 md:px-8">
        <AnimateOnScroll className="text-center max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-100 mb-4">Trusted by Industry Leaders</h2>
            <p className="text-lg text-slate-400 mb-12">
                Join thousands of businesses that trust us for their lead generation needs
            </p>
        </AnimateOnScroll>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-y-10 gap-x-8">
            <AnimateOnScroll delay={0} animation="zoom-in"><AnimatedStatItem value="50M+" label="Leads Generated" /></AnimateOnScroll>
            <AnimateOnScroll delay={100} animation="zoom-in"><AnimatedStatItem value="10K+" label="Active Clients" /></AnimateOnScroll>
            <AnimateOnScroll delay={200} animation="zoom-in"><AnimatedStatItem value="98.7%" label="Client Satisfaction" /></AnimateOnScroll>
            <AnimateOnScroll delay={300} animation="zoom-in"><AnimatedStatItem value="5+" label="Years Experience" /></AnimateOnScroll>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 md:px-8">
          <div className="text-center mb-12">
            <AnimateOnScroll animation="fade-in-up">
                <h3 className="text-base font-semibold uppercase tracking-wider text-emerald-400">How we can help</h3>
                <h2 className="text-3xl md:text-4xl font-bold text-slate-100 mt-2 mb-4">Gain Insights From Every Interaction</h2>
            </AnimateOnScroll>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <AnimateOnScroll key={feature.title} delay={100 * (index + 1)} className="h-full">
                  <GlassCard className="p-8">
                      <FeatureItem index={index} icon={feature.icon} title={feature.title} description={feature.description} />
                  </GlassCard>
                </AnimateOnScroll>
              ))}
          </div>
      </section>

      {/* The Quantum Difference Section */}
      <section className="container mx-auto px-4 md:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
              <AnimateOnScroll animation="fade-in-left" delay={100}>
                  <div className="p-2 bg-zinc-700/40 rounded-2xl shadow-lg shadow-black/30 border border-zinc-700/50">
                       <img
                          src="https://media.istockphoto.com/id/1690296731/photo/business-woman-call-center-and-typing-on-computer-for-e-commerce-customer-service-and-virtual.jpg?s=612x612&w=0&k=20&c=LVvmBoHVmjlzVNkSEyQdE2Q5mt8h0TO9ra2XU-OOBRg="
                          alt="Customer service agent connecting with a client"
                          className="rounded-xl w-full h-full object-cover"
                       />
                  </div>
              </AnimateOnScroll>
              <AnimateOnScroll animation="fade-in-right" delay={200}>
                  <div>
                      <h3 className="text-base font-semibold uppercase tracking-wider text-emerald-400">The Quantum Difference</h3>
                      <h2 className="text-3xl md:text-4xl font-bold text-slate-100 mt-2 mb-4">Beyond Data: The Human Connection</h2>
                      <p className="text-slate-400 text-lg mb-6">
                          In a world of automation, we believe in the power of genuine human interaction. Our agents don't just verify leads; they build rapport and identify true intent, ensuring that when you connect with a prospect, the conversation is already warm.
                      </p>
                      <ul className="space-y-3 text-slate-300 mb-8">
                          <li className="flex items-start">
                              <svg className="w-6 h-6 text-emerald-400 mr-3 flex-shrink-0 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                              <span><strong>Higher Conversion Rates</strong> through pre-qualified, engaged prospects.</span>
                          </li>
                          <li className="flex items-start">
                              <svg className="w-6 h-6 text-emerald-400 mr-3 flex-shrink-0 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                              <span><strong>Enhanced Customer Rapport</strong> before the first sales call.</span>
                          </li>
                          <li className="flex items-start">
                              <svg className="w-6 h-6 text-emerald-400 mr-3 flex-shrink-0 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                              <span><strong>Actionable Insights</strong> from real conversations with your target market.</span>
                          </li>
                      </ul>
                      <Link to="/why-us">
                          <button className="bg-transparent text-white font-semibold py-3 px-8 rounded-lg hover:bg-zinc-800 transition-all duration-300 border border-zinc-700">
                              Discover Why We're Different
                          </button>
                      </Link>
                  </div>
              </AnimateOnScroll>
          </div>
      </section>
      
      {/* How we work section */}
      <section className="text-center container mx-auto px-4 md:px-8">
        <AnimateOnScroll animation="fade-in-up">
            <h3 className="text-base font-semibold uppercase tracking-wider text-emerald-400">How we work</h3>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-100 mt-2 mb-4">A Simple, Transparent Process</h2>
            <p className="max-w-2xl mx-auto text-slate-400 text-lg mb-12">We communicate to get your business to the next level.</p>
        </AnimateOnScroll>
        <div className="grid md:grid-cols-3 gap-8 text-center">
            {processSteps.map((step, index) => (
              <AnimateOnScroll key={step.title} delay={200 * (index + 1)} animation="fade-in-up">
                <GlassCard className="p-8 flex flex-col items-center">
                  <div className="inline-block p-4 bg-zinc-700 rounded-xl mb-4 text-emerald-400">
                    {step.icon}
                  </div>
                  <h3 className="text-xl font-bold mb-2 text-slate-200">{step.title}</h3>
                  <p className="text-slate-400">{step.description}</p>
                </GlassCard>
              </AnimateOnScroll>
            ))}
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="container mx-auto px-4 md:px-8">
          <AnimateOnScroll className="text-center max-w-4xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-slate-100 mb-4">They Trust QuantumLeads</h2>
              <p className="text-lg text-slate-400 mb-12">
                  Real stories from businesses we've helped grow.
              </p>
          </AnimateOnScroll>
          <AnimateOnScroll animation="fade-in-up" className="relative max-w-5xl mx-auto h-[450px] flex items-center justify-center px-12">
            <button
                onClick={prevTestimonial}
                className="absolute top-1/2 left-0 transform -translate-y-1/2 bg-zinc-800 hover:bg-zinc-700 rounded-full p-3 text-slate-300 transition-colors z-20 border border-zinc-700 shadow-md shadow-black/30"
                aria-label="Previous testimonial"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
            </button>

            <div className="w-[320px] h-[400px]" style={{ perspective: '1000px' }}>
                <div className="relative w-full h-full" style={{ transformStyle: 'preserve-3d' }}>
                    {testimonials.map((testimonial, index) => {
                        const total = testimonials.length;
                        const offset = ((index - activeTestimonial) % total + total) % total;
                        
                        let displayOffset = 0;
                        if (offset === 1) { displayOffset = 1; }
                        else if (offset === total - 1) { displayOffset = -1; }
                        else if (offset !== 0) {
                            displayOffset = offset > total / 2 ? -2 : 2; 
                        }

                        let transform = 'scale(0.5)';
                        let zIndex = 0;
                        let opacity = 0;
                        
                        switch (displayOffset) {
                            case 0:
                                transform = 'translateX(0) rotateY(0) scale(1)';
                                zIndex = 10;
                                opacity = 1;
                                break;
                            case -1:
                                transform = 'translateX(-60%) rotateY(35deg) scale(0.85)';
                                zIndex = 5;
                                opacity = 0.6;
                                break;
                            case 1:
                                transform = 'translateX(60%) rotateY(-35deg) scale(0.85)';
                                zIndex = 5;
                                opacity = 0.6;
                                break;
                            default:
                                transform = `translateX(${displayOffset * 50}%) rotateY(${displayOffset > 0 ? -35 : 35}deg) scale(0.7)`;
                                zIndex = 0;
                                opacity = 0;
                        }

                        return (
                            <div
                                key={index}
                                className="absolute w-full h-full"
                                style={{
                                    transform: transform,
                                    zIndex: zIndex,
                                    opacity: opacity,
                                    transition: 'transform 0.5s ease-out, opacity 0.5s ease-out',
                                }}
                            >
                                <GlassCard className="p-6 h-full flex flex-col justify-center items-center text-center">
                                    <img src={testimonial.image} alt={testimonial.name} className="w-24 h-24 rounded-full object-cover mb-4 border-2 border-zinc-700 shadow-lg" />
                                     <div className="flex items-center justify-center mb-3">
                                        {Array.from({ length: testimonial.rating }).map((_, i) => (
                                            <StarIcon key={i} />
                                        ))}
                                    </div>
                                    <blockquote className="text-md text-slate-400 mb-4 italic flex-grow">
                                        &ldquo;{testimonial.quote}&rdquo;
                                    </blockquote>
                                    <div>
                                        <p className="font-semibold text-slate-200">{testimonial.name}</p>
                                        <p className="text-sm text-slate-400">{testimonial.title}</p>
                                    </div>
                                </GlassCard>
                            </div>
                        )
                    })}
                </div>
            </div>

            <button
                onClick={nextTestimonial}
                className="absolute top-1/2 right-0 transform -translate-y-1/2 bg-zinc-800 hover:bg-zinc-700 rounded-full p-3 text-slate-300 transition-colors z-20 border border-zinc-700 shadow-md shadow-black/30"
                aria-label="Next testimonial"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
            </button>
          </AnimateOnScroll>
      </section>

       {/* CTA Section */}
      <section className="container mx-auto px-4 md:px-8">
        <AnimateOnScroll animation="zoom-in">
          <div className="bg-zinc-800/50 border border-zinc-700/50 rounded-2xl p-8 md:p-12 overflow-hidden">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="text-center md:text-left order-2 md:order-1">
                <h2 className="text-3xl md:text-4xl font-bold text-slate-100 mb-4">
                  Ready to Amplify Your Growth?
                </h2>
                <p className="text-lg text-slate-400 mb-8">
                  Partner with QuantumLeads and unlock a predictable stream of high-quality leads. Let's build your success story together.
                </p>
                <Link to="/contact">
                  <button className="bg-gradient-to-r from-green-400 via-emerald-500 to-sky-500 animate-gradient text-white font-semibold py-3 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg shadow-emerald-500/10">
                    Get a Free Consultation
                  </button>
                </Link>
              </div>
              <div className="order-1 md:order-2">
                <div className="p-2 bg-zinc-700/40 rounded-2xl shadow-lg shadow-black/30 border border-zinc-700/50">
                    <img
                        src="https://media.istockphoto.com/id/2056747068/photo/business-people-attending-a-hybrid-presentation.jpg?s=612x612&w=0&k=20&c=kE6XdNOSgl39FZBUg4a7_6DdBKnCdbztqseCCXtCVlA="
                        alt="Business people attending a hybrid presentation"
                        className="rounded-xl w-full h-full object-cover"
                    />
                </div>
              </div>
            </div>
          </div>
        </AnimateOnScroll>
      </section>
    </div>
  );
};

export default HomePage;