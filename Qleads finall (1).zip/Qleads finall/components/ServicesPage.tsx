
import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';

// Reusable component for scroll animations
interface AnimateOnScrollProps {
    children: React.ReactNode;
    className?: string;
    animation?: 'fade-in-up' | 'fade-in-down' | 'fade-in-left' | 'fade-in-right' | 'zoom-in';
    delay?: number;
    as?: React.ElementType;
}

const AnimateOnScroll: React.FC<AnimateOnScrollProps> = ({
    children,
    className = '',
    animation = 'fade-in-up',
    delay = 0,
    as: Tag = 'div',
}) => {
    const ref = useRef<HTMLElement>(null);
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    setIsVisible(true);
                    observer.unobserve(entry.target);
                }
            },
            { threshold: 0.1 }
        );

        const currentRef = ref.current;
        if (currentRef) {
            observer.observe(currentRef);
        }

        return () => {
            if (currentRef) {
                observer.unobserve(currentRef);
            }
        };
    }, []);

    const combinedClassName = `scroll-animate ${animation} ${isVisible ? 'is-visible' : ''} ${className}`;

    return (
        <Tag
            ref={ref}
            className={combinedClassName}
            style={{ transitionDelay: `${delay}ms` }}
        >
            {children}
        </Tag>
    );
};


const PageHeader = ({ title, subtitle }: { title: string, subtitle:string }) => (
    <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-sky-400 mb-4">{title}</h1>
        <p className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto">{subtitle}</p>
    </div>
);

const ServiceCard = ({ imageUrl, title, description, id }: { imageUrl: string, title: string, description: string, id: string }) => (
    <div className="bg-zinc-800/50 backdrop-blur-lg border border-zinc-700/50 rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl hover:shadow-emerald-400/30 hover:border-emerald-400/50 group h-full flex flex-col">
        <div className="overflow-hidden h-56">
            <img src={imageUrl} alt={title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out" />
        </div>
        <div className="p-8 flex flex-col flex-grow">
            <h3 className="text-2xl font-bold text-slate-100 mb-3">{title}</h3>
            <p className="text-slate-400 leading-relaxed flex-grow">{description}</p>
            <div className="mt-6">
                 <Link to={`/service-details#${id}`} className="block text-center">
                    <button className="w-full bg-transparent text-emerald-400 font-semibold py-2 px-4 rounded-lg border border-emerald-400 hover:bg-emerald-400 hover:text-slate-900 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-2 focus:ring-offset-zinc-800">
                        Learn More
                    </button>
                </Link>
            </div>
        </div>
    </div>
);

const AnimatedStatItem = ({ value, label }: { value: string, label: string }) => {
    const [count, setCount] = useState(0);
    const ref = useRef<HTMLDivElement>(null);
    const hasAnimated = useRef(false);

    const endValue = parseInt(value.replace(/,/g, '').replace(/[+%]/g, ''));
    const suffix = value.match(/[+%]/)?.[0] || '';

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting && !hasAnimated.current) {
                    hasAnimated.current = true;
                    
                    let startTimestamp: number | null = null;
                    const duration = 2000; // Animation duration in ms

                    const step = (timestamp: number) => {
                        if (!startTimestamp) startTimestamp = timestamp;
                        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
                        setCount(Math.floor(progress * endValue));
                        if (progress < 1) {
                            window.requestAnimationFrame(step);
                        }
                    };
                    window.requestAnimationFrame(step);
                }
            },
            {
                threshold: 0.5,
            }
        );

        const currentRef = ref.current;
        if (currentRef) {
            observer.observe(currentRef);
        }

        return () => {
            if (currentRef) {
                observer.unobserve(currentRef);
            }
        };
    }, [endValue]);

    return (
        <div className="text-center" ref={ref}>
            <p className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-sky-400">
                {count.toLocaleString()}{suffix}
            </p>
            <p className="text-slate-400 mt-2">{label}</p>
        </div>
    );
};

const ProcessStep = ({ number, title, description }: { number: string, title: string, description: string }) => (
    <div className="text-center flex flex-col items-center">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500 to-sky-500 text-white flex items-center justify-center text-2xl font-bold mb-6 shadow-lg shadow-emerald-500/20">
            {number}
        </div>
        <h3 className="text-xl font-bold text-slate-200 mb-2">{title}</h3>
        <p className="text-slate-400 max-w-xs">{description}</p>
    </div>
);

const ServicesPage: React.FC = () => {
  const services = [
    {
      id: 'inbound-calls',
      imageUrl: 'https://images.pexels.com/photos/7709289/pexels-photo-7709289.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Inbound Calls',
      description: 'Verified calls from US customers ready to buy. We connect you directly with prospects who have high purchase intent.'
    },
    {
      id: 'exclusive-leads',
      imageUrl: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Exclusive Leads',
      description: 'No reselling. Leads are generated exclusively for your business, ensuring higher quality and conversion rates.'
    },
    {
      id: 'pay-per-lead-campaigns',
      imageUrl: 'https://media.istockphoto.com/id/1411993727/photo/business-analysis-big-data-screen-and-economic-growth-with-financial-graph-concept-of-virtual.jpg?s=612x612&w=0&k=20&c=YDaYtnHlX7NrKemhyweeNlNNZ57xvdzJxzxRDZP3HCw=',
      title: 'Pay Per Lead Campaigns',
      description: 'A completely risk-free, performance-based model. You only pay for the verified leads we deliver.'
    },
    {
      id: 'custom-campaigns',
      imageUrl: 'https://media.istockphoto.com/id/1132912639/photo/network-of-business-concept.jpg?s=612x612&w=0&k=20&c=V_vQ_gT_mOsfDWKrnWxEcnWEYvjk1hUirhv9NfW6uFE=',
      title: 'Custom Campaigns',
      description: 'Tailored solutions designed to meet your specific business needs and marketing objectives for maximum impact.'
    }
  ];

  const stats = [
    { value: '2,847+', label: 'Leads Generated' },
    { value: '98%', label: 'Accuracy Rate' },
    { value: '24', label: 'Hour Support' },
    { value: '127%', label: 'ROI Increase' },
  ];

  const processSteps = [
    { number: '01', title: 'Consultation', description: 'We analyze your business needs and target audience' },
    { number: '02', title: 'Campaign Setup', description: 'Custom campaigns designed for your specific requirements' },
    { number: '03', title: 'Lead Generation', description: 'Real-time lead generation using advanced targeting' },
    { number: '04', title: 'Delivery & Support', description: 'Instant lead delivery with ongoing optimization' },
  ];

  return (
    <div className="py-12 space-y-24 container mx-auto px-4 md:px-8">
      <div className="bg-zinc-800 border border-zinc-700/60 rounded-2xl p-8 md:p-12">
        <AnimateOnScroll>
          <PageHeader title="Our Services" subtitle="Tailored Solutions to Grow Your Business" />
        </AnimateOnScroll>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <AnimateOnScroll key={service.title} delay={index * 100} animation="zoom-in" className="h-full">
              <ServiceCard {...service} />
            </AnimateOnScroll>
          ))}
        </div>
      </div>

      {/* How It Works Section */}
      <AnimateOnScroll as="section" className="py-20 bg-zinc-900/70 rounded-3xl border border-zinc-800">
        <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto">
                <h2 className="text-4xl md:text-5xl font-extrabold text-slate-100 mb-4">How It Works</h2>
                <p className="text-lg text-slate-400">Our streamlined process ensures you get high-quality leads quickly and efficiently</p>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-y-12 gap-x-8 my-16 max-w-5xl mx-auto">
                {stats.map((stat, index) => (
                    <AnimateOnScroll key={stat.label} delay={index * 100} animation="zoom-in">
                        <AnimatedStatItem {...stat} />
                    </AnimateOnScroll>
                ))}
            </div>

            <div className="relative mt-20 max-w-6xl mx-auto">
                 <div className="absolute top-8 left-0 w-full h-0.5 bg-zinc-700 hidden lg:block" aria-hidden="true"></div>
                 <div className="relative grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-y-16 gap-x-8">
                    {processSteps.map((step, index) => (
                       <AnimateOnScroll key={step.number} delay={index * 150}>
                           <ProcessStep {...step} />
                       </AnimateOnScroll>
                    ))}
                </div>
            </div>
        </div>
      </AnimateOnScroll>
    </div>
  );
};

export default ServicesPage;