
import React, { useState, useEffect, useRef } from 'react';

// Reusable component for scroll animations
interface AnimateOnScrollProps {
    children: React.ReactNode;
    className?: string;
    animation?: 'fade-in-up' | 'fade-in-down' | 'fade-in-left' | 'fade-in-right' | 'zoom-in';
    delay?: number;
    as?: React.ElementType;
    id?: string;
}

const AnimateOnScroll: React.FC<AnimateOnScrollProps> = ({
    children,
    className = '',
    animation = 'fade-in-up',
    delay = 0,
    as: Tag = 'div',
    id,
}) => {
    const ref = useRef<HTMLElement>(null);
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    setIsVisible(true);
                    observer.unobserve(entry.target);
                }
            },
            { threshold: 0.1 }
        );

        const currentRef = ref.current;
        if (currentRef) {
            observer.observe(currentRef);
        }

        return () => {
            if (currentRef) {
                observer.unobserve(currentRef);
            }
        };
    }, []);

    const combinedClassName = `scroll-animate ${animation} ${isVisible ? 'is-visible' : ''} ${className}`;

    return (
        <Tag
            id={id}
            ref={ref}
            className={combinedClassName}
            style={{ transitionDelay: `${delay}ms` }}
        >
            {children}
        </Tag>
    );
};

const PageHeader = ({ title, subtitle }: { title: string, subtitle: string }) => (
    <AnimateOnScroll animation="fade-in-down" className="text-center">
        <h1 className="text-4xl md:text-5xl font-extrabold text-slate-100 mb-3">{title}</h1>
        <p className="text-lg text-slate-400 max-w-3xl mx-auto">{subtitle}</p>
        <div className="mt-4 h-1 w-24 bg-gradient-to-r from-emerald-500 to-sky-400 mx-auto rounded-full"></div>
    </AnimateOnScroll>
);

const InteractiveCard: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => {
    const cardRef = useRef<HTMLDivElement>(null);

    const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
        if (!cardRef.current) return;
        const rect = cardRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        cardRef.current.style.setProperty('--mouse-x', `${x}px`);
        cardRef.current.style.setProperty('--mouse-y', `${y}px`);
    };

    return (
        <div
            ref={cardRef}
            onMouseMove={handleMouseMove}
            className={`glass-card-interactive overflow-hidden ${className}`}
        >
            <div className="relative z-10 h-full">
                {children}
            </div>
        </div>
    );
};

// Simplified timeline for mobile
const MobileTimelineItem = ({ year, title, description, delay }: { year: string, title: string, description: string, delay: number }) => (
    <div className="flex items-start w-full">
        <div className="w-12 flex-shrink-0 flex justify-center">
             <div className="h-full w-0.5 bg-zinc-700 relative">
                 <div className="absolute top-6 -translate-y-1/2 left-1/2 -translate-x-1/2 z-10 bg-zinc-900 p-1 rounded-full">
                    <div className="w-4 h-4 rounded-full bg-emerald-500 border-2 border-zinc-800"></div>
                </div>
             </div>
        </div>
        <div className="w-full pl-4 pb-8">
            <AnimateOnScroll animation="fade-in-left" delay={delay}>
                <InteractiveCard className="bg-zinc-800/50 border border-zinc-700/50 rounded-xl p-6 shadow-lg">
                    <p className="text-lg font-bold text-emerald-400 mb-1">{year}</p>
                    <h3 className="text-xl font-semibold text-slate-200 mb-2">{title}</h3>
                    <p className="text-slate-400">{description}</p>
                </InteractiveCard>
            </AnimateOnScroll>
        </div>
    </div>
);

const AboutPage: React.FC = () => {
    const timelineData = [
        { year: '2019', title: 'The Idea Was Born', description: 'Observing a gap in the market for high-quality, exclusive leads, our founders conceptualized QuantumLeads to deliver value and transparency.'},
        { year: '2020', title: 'Company Launch', description: 'QuantumLeads officially launched as a UK-registered entity, with an initial focus on providing Pay-Per-Lead services to the US market.' },
        { year: '2022', title: 'Expansion of Services', description: 'We expanded our offerings to include Inbound Calls and Custom Campaigns, catering to a wider range of business needs.' },
        { year: '2024', title: 'Milestone Achievement', description: 'Celebrating over 50 million leads generated and serving more than 10,000 active clients, solidifying our position as industry leaders.' }
    ];

    const teamMembers = [
        { name: 'John Carter', title: 'CEO & Founder', image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=400' },
        { name: 'Sophie Moore', title: 'Head of Marketing', image: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=400' },
        { name: 'David Lee', title: 'Chief Technology Officer', image: 'https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=400' }
    ];

    return (
        <div>
            {/* Banner Section */}
            <section className="relative py-20 md:py-28 text-center overflow-hidden">
                <div 
                    aria-hidden="true" 
                    className="absolute inset-0 z-0 bg-cover bg-center" 
                    style={{ backgroundImage: "url('https://media.istockphoto.com/id/1185978251/photo/people-in-a-call-centre-conducting-market-research.jpg?s=612x612&w=0&k=20&c=sf9QPrLSIZHfH9cicEjF2aEYB1kIOGgUqM781BeCsMg=')" }}
                ></div>
                <div aria-hidden="true" className="absolute inset-0 z-1 bg-zinc-900/70 backdrop-blur-sm"></div>
                <div className="relative z-10 container mx-auto px-4 md:px-8">
                    <PageHeader 
                        title="About Us"
                        subtitle="Discover the story, mission, and team dedicated to fueling your business growth in the US market."
                    />
                </div>
            </section>

            <div className="container mx-auto px-4 md:px-8 py-12 space-y-24">
                {/* Who We Are Section */}
                <section>
                    <AnimateOnScroll animation="fade-in-up" delay={100}>
                        <div className="max-w-4xl mx-auto text-center">
                             <h2 className="text-3xl font-bold text-slate-100 mb-4">Who We Are</h2>
                             <p className="text-lg text-slate-400 leading-relaxed">
                                We are a UK-based lead generation company with a strong presence in the US market. Our team specializes in delivering real-time, high-intent leads for businesses across different industries. Whether you’re looking for inbound calls, form fills, or custom campaigns, we help you connect with the right audience at the right time.
                            </p>
                        </div>
                    </AnimateOnScroll>
                </section>
                
                {/* Our Journey Timeline */}
                <section id="our-journey">
                    <AnimateOnScroll className="text-center mb-16">
                        <h2 className="text-3xl font-bold text-slate-100">Our Journey</h2>
                        <p className="text-slate-400 mt-2">A timeline of our dedication and growth.</p>
                    </AnimateOnScroll>
                    
                    {/* Desktop Timeline */}
                    <div className="hidden md:block max-w-4xl mx-auto">
                        <div className="relative wrap overflow-hidden h-full">
                            <div className="border-2-2 absolute border-opacity-20 border-zinc-700 h-full border" style={{ left: '50%' }}></div>
                             {timelineData.map((item, index) => (
                                <div key={item.year} className={`mb-8 flex justify-between items-center w-full ${index % 2 === 0 ? 'flex-row-reverse left-timeline' : 'right-timeline'}`}>
                                    <div className="order-1 w-5/12"></div>
                                    <div className="z-20 flex items-center order-1 bg-zinc-900 shadow-xl w-6 h-6 rounded-full ring-4 ring-emerald-500">
                                    </div>
                                    <InteractiveCard className="order-1 bg-zinc-800/50 border border-zinc-700/50 rounded-lg shadow-xl w-5/12 px-6 py-4">
                                        <AnimateOnScroll animation={index % 2 === 0 ? 'fade-in-left' : 'fade-in-right'}>
                                            <p className="text-lg font-bold text-emerald-400 mb-1">{item.year}</p>
                                            <h3 className="mb-3 font-bold text-slate-200 text-xl">{item.title}</h3>
                                            <p className="text-sm leading-snug tracking-wide text-slate-400 text-opacity-100">{item.description}</p>
                                        </AnimateOnScroll>
                                    </InteractiveCard>
                                </div>
                             ))}
                        </div>
                    </div>

                     {/* Mobile Timeline */}
                     <div className="md:hidden relative flex flex-col items-start">
                         {timelineData.map((item, index) => (
                            <MobileTimelineItem key={item.year} {...item} delay={index * 150} />
                         ))}
                    </div>
                </section>

                {/* Mission Section */}
                <section className="text-center max-w-4xl mx-auto">
                    <AnimateOnScroll>
                        <h2 className="text-3xl font-bold text-slate-100 mb-4">Our Mission</h2>
                        <InteractiveCard className="bg-zinc-800/40 border border-zinc-700/50 rounded-xl p-8 shadow-lg">
                            <p className="text-xl text-slate-300 leading-relaxed italic">
                                &ldquo;To be the most trusted and effective lead generation partner for businesses targeting the US market, by consistently delivering high-quality, verified, and exclusive leads that drive measurable growth and ROI.&rdquo;
                            </p>
                        </InteractiveCard>
                    </AnimateOnScroll>
                </section>

                {/* Team Section */}
                <section>
                    <AnimateOnScroll className="text-center mb-12">
                        <h2 className="text-3xl font-bold text-slate-100">Meet The Team</h2>
                        <p className="text-slate-400 mt-2">The passionate individuals driving our success.</p>
                    </AnimateOnScroll>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
                        {teamMembers.map((member, index) => (
                            <AnimateOnScroll key={member.name} delay={index * 150} animation="zoom-in">
                                <div className="text-center group p-4 bg-zinc-800/30 rounded-xl transition-all duration-300 hover:bg-zinc-800/60 hover:shadow-2xl hover:shadow-emerald-500/10">
                                    <div className="relative inline-block">
                                        <img src={member.image} alt={member.name} className="w-32 h-32 rounded-full object-cover mx-auto mb-4 border-4 border-zinc-700 group-hover:border-emerald-500 transition-colors duration-300"/>
                                        <div className="absolute inset-0 rounded-full group-hover:shadow-[0_0_25px_5px_rgba(52,211,153,0.3)] transition-shadow duration-300"></div>
                                    </div>
                                    <h3 className="text-xl font-semibold text-slate-200">{member.name}</h3>
                                    <p className="text-emerald-400">{member.title}</p>
                                </div>
                            </AnimateOnScroll>
                        ))}
                    </div>
                </section>
            </div>
        </div>
    );
};

export default AboutPage;