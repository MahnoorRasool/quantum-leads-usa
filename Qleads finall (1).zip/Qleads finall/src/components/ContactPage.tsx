
import React, { useState, useEffect, useRef } from 'react';

interface AnimateOnScrollProps {
    children: React.ReactNode;
    className?: string;
    animation?: 'fade-in-up' | 'fade-in-down' | 'fade-in-left' | 'fade-in-right' | 'zoom-in';
    delay?: number;
    as?: React.ElementType;
}

const AnimateOnScroll: React.FC<AnimateOnScrollProps> = ({
    children,
    className = '',
    animation = 'fade-in-up',
    delay = 0,
    as: Tag = 'div',
}) => {
    const ref = useRef<HTMLElement>(null);
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    setIsVisible(true);
                    observer.unobserve(entry.target);
                }
            },
            { threshold: 0.1 }
        );

        const currentRef = ref.current;
        if (currentRef) {
            observer.observe(currentRef);
        }

        return () => {
            if (currentRef) {
                observer.unobserve(currentRef);
            }
        };
    }, []);

    const combinedClassName = `scroll-animate ${animation} ${isVisible ? 'is-visible' : ''} ${className}`;

    return (
        <Tag
            ref={ref}
            className={combinedClassName}
            style={{ transitionDelay: `${delay}ms` }}
        >
            {children}
        </Tag>
    );
};


const PageHeader = ({ title, subtitle }: { title: string, subtitle: string }) => (
    <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-extrabold text-slate-100 mb-3">{title}</h1>
        <p className="text-lg text-slate-400">{subtitle}</p>
        <div className="mt-4 h-1 w-24 bg-gradient-to-r from-emerald-500 to-sky-400 mx-auto rounded-full"></div>
    </div>
);

const ContactPage: React.FC = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        businessType: '',
        message: ''
    });

    const [status, setStatus] = useState('');

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prevState => ({ ...prevState, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setStatus('Sending...');
        // In a real app, you'd send this data to a server.
        console.log("Form Data Submitted:", formData);
        setTimeout(() => {
            setStatus('Your message has been sent successfully!');
            setFormData({ name: '', email: '', businessType: '', message: '' });
             setTimeout(() => setStatus(''), 3000);
        }, 1500);
    };
    
    const inputClasses = "w-full bg-zinc-800 border-zinc-700 rounded-lg p-3 text-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all duration-300 placeholder-slate-500";
    
    return (
        <div className="py-12 container mx-auto px-4 md:px-8">
            <AnimateOnScroll>
                <PageHeader title="Contact Us" subtitle="Let's Start a Conversation" />
            </AnimateOnScroll>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start max-w-7xl mx-auto">
                {/* Left side: Form with embedded image */}
                <AnimateOnScroll animation="fade-in-right" className="h-full">
                    <div className="bg-zinc-800/40 border border-zinc-700/50 rounded-2xl shadow-2xl shadow-black/30 h-full flex flex-col lg:flex-row overflow-hidden">
                        <div className="lg:w-2/5 w-full">
                           <img
                                src="https://media.istockphoto.com/id/637945400/photo/modern-white-keyboard-wih-three-blue-colored-contact-us-buttons.jpg?s=612x612&w=0&k=20&c=OOiD7TeD4ZkiK33vIhh5t-HZrGf0SgO8e2PbdX136LY="
                                alt="Contact us keyboard with blue buttons"
                                className="w-full h-64 lg:h-full object-cover"
                            />
                        </div>
                        <div className="lg:w-3/5 w-full p-8">
                            <h3 className="text-2xl font-bold mb-6 text-slate-100">Send us a Message</h3>
                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div>
                                    <label htmlFor="name" className="block mb-2 text-sm font-medium text-slate-400">Name</label>
                                    <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} className={inputClasses} placeholder="Your Name" required />
                                </div>
                                <div>
                                    <label htmlFor="email" className="block mb-2 text-sm font-medium text-slate-400">Email</label>
                                    <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} className={inputClasses} placeholder="your.email@company.com" required />
                                </div>
                                <div>
                                    <label htmlFor="businessType" className="block mb-2 text-sm font-medium text-slate-400">Business Type</label>
                                    <input type="text" name="businessType" id="businessType" value={formData.businessType} onChange={handleChange} className={inputClasses} placeholder="e.g., SaaS, E-commerce" required />
                                </div>
                                <div>
                                    <label htmlFor="message" className="block mb-2 text-sm font-medium text-slate-400">Message</label>
                                    <textarea name="message" id="message" rows={4} value={formData.message} onChange={handleChange} className={inputClasses} placeholder="How can we help you?" required></textarea>
                                </div>
                                <button type="submit" className="w-full animate-gradient bg-gradient-to-r from-green-400 via-emerald-500 to-sky-600 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-300 shadow-lg shadow-emerald-500/20 transform hover:scale-105 disabled:bg-slate-600">
                                    Send Message
                                </button>
                                {status && <p className="text-center text-emerald-400 mt-4">{status}</p>}
                            </form>
                        </div>
                    </div>
                </AnimateOnScroll>

                {/* Right side: Contact Info and Map */}
                <div className="space-y-8">
                    <AnimateOnScroll animation="fade-in-left" delay={100}>
                        <div className="space-y-4">
                            <h3 className="text-2xl font-bold text-slate-100">Other Ways to Reach Us</h3>
                            <ContactInfoItem icon={<PhoneIcon />} title="Direct Phone" content="+1 (234) 567-890" href="tel:+1234567890" />
                            <ContactInfoItem icon={<EmailIcon />} title="Email" content="contact@quantumleads.com" href="mailto:contact@quantumleads.com" />
                            <ContactInfoItem icon={<WhatsAppIcon />} title="WhatsApp" content="Chat with us" href="https://wa.me/1234567890" />
                        </div>
                    </AnimateOnScroll>

                    <AnimateOnScroll animation="fade-in-left" delay={200}>
                        <div className="bg-zinc-800/50 border border-zinc-700/50 rounded-2xl p-6 shadow-xl shadow-black/20">
                            <h3 className="text-2xl font-bold mb-4 text-slate-100">Our Location</h3>
                            <p className="text-slate-400 mb-4">Business Center, Block 6, PECHS, Karachi, Pakistan</p>
                            <div className="rounded-lg overflow-hidden border border-zinc-700 h-64">
                                <iframe
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3620.0389332560826!2d67.0693200759082!3d24.862512645025774!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb33ff324548a87%3A0x736504a433224b91!2sPECHS%2C%2C%20Block%206%20PECHS%2C%20Karachi%2C%20Karachi%20City%2C%20Sindh%2C%20Pakistan!5e0!3m2!1sen!2s!4v1709895432109!5m2!1sen!2s"
                                    width="100%"
                                    height="100%"
                                    style={{ border: 0 }}
                                    allowFullScreen={false}
                                    loading="lazy"
                                    referrerPolicy="no-referrer-when-downgrade"
                                    className="[filter:grayscale(1)_invert(1)_contrast(0.9)_hue-rotate(190deg)_brightness(0.9)_saturate(0.5)]"
                                ></iframe>
                            </div>
                        </div>
                    </AnimateOnScroll>
                </div>
            </div>
        </div>
    );
};

interface ContactInfoItemProps {
    icon: React.ReactNode;
    title: string;
    content: string;
    href: string;
}

const ContactInfoItem: React.FC<ContactInfoItemProps> = ({ icon, title, content, href }) => (
    <a href={href} target="_blank" rel="noopener noreferrer" className="bg-zinc-800/50 backdrop-blur-lg border border-zinc-700/50 rounded-xl p-4 flex items-center space-x-4 transition-all duration-300 hover:border-emerald-500/50 hover:shadow-lg hover:-translate-y-1 group">
        <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-zinc-700 text-emerald-400 flex items-center justify-center transition-colors duration-300">
            {icon}
        </div>
        <div>
            <h4 className="text-lg font-semibold text-slate-200">{title}</h4>
            <p className="text-slate-400 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-emerald-400 group-hover:to-sky-500 transition-colors">{content}</p>
        </div>
    </a>
);


const PhoneIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>;
const EmailIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>;
const WhatsAppIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.371-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01s-.521.074-.792.372c-.272.296-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.626.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>;

export default ContactPage;