
import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const EmailIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207" />
    </svg>
);

const LockIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
    </svg>
);

const UserIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
);

const EyeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-400 group-hover:text-white transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
    </svg>
);

const EyeSlashIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-400 group-hover:text-white transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.542-7 .946-3.11 3.558-5.512 6.83-6.18M15 12a3 3 0 11-6 0 3 3 0 016 0zm6 0c.055.16.107.32.155.485 1.274 4.057-2.37 7.515-6.691 7.515a10.01 10.01 0 01-2.02-.205M3 3l18 18" />
    </svg>
);

const BackArrowIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
    </svg>
);


const LoginPage: React.FC = () => {
    const [view, setView] = useState<'login' | 'register' | 'forgot'>('login');
    const [showPassword, setShowPassword] = useState(false);
    const [showRetypePassword, setShowRetypePassword] = useState(false);
    const [resetStatus, setResetStatus] = useState('');

    const loginImageUrl = "https://media.istockphoto.com/id/1308038052/photo/close-up-on-headset-telephone-with-cloud-data-center-to-synchronize-on-saas-host-server-to.jpg?s=612x612&w=0&k=20&c=TgnzeWyTtkwojzmhiOzOahmPc01tvRaMNhvhpqnXipI=";
    const registerImageUrl = "https://media.istockphoto.com/id/1482945153/photo/close-up-cropped-shot-of-unrecognizable-business-partners-handshaking-after-close-deal-and.jpg?s=612x612&w=0&k=20&c=T4Gm7IgIc5uY5t0IftueicQAD5_i2iZcqj3mygR_M6E=";

    const handleResetSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setResetStatus('Sending...');
        setTimeout(() => {
            setResetStatus('If an account exists for this email, a reset link has been sent.');
            setTimeout(() => setResetStatus(''), 5000);
        }, 1500);
    };

    const activeTab = view === 'register' ? 'register' : 'login';

    return (
        <div className="relative min-h-screen w-full flex items-center justify-center bg-zinc-900">
            {/* Back Arrow to Homepage */}
            <Link to="/" className="absolute top-6 left-6 z-20 text-slate-300 hover:text-white transition-all duration-300 transform hover:scale-110" aria-label="Go back to homepage">
                <div className="p-3 rounded-full bg-zinc-800/50 hover:bg-zinc-700/70 backdrop-blur-md border border-zinc-700/50 shadow-lg">
                    <BackArrowIcon />
                </div>
            </Link>

             {/* Background Images */}
            <div
                className="absolute inset-0 bg-cover bg-center transition-opacity duration-700 ease-in-out"
                style={{
                    backgroundImage: `url(${loginImageUrl})`,
                    opacity: view === 'register' ? 0 : 1
                }}
            />
            <div
                className="absolute inset-0 bg-cover bg-center transition-opacity duration-700 ease-in-out"
                style={{
                    backgroundImage: `url(${registerImageUrl})`,
                    opacity: view === 'register' ? 1 : 0
                }}
            />
            
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-r from-zinc-900/30 via-zinc-900/80 to-zinc-900"></div>

            <div className="relative z-10 w-full max-w-5xl mx-auto p-4">
                <div className="flex flex-col md:flex-row items-center">
                    
                    {/* Left Side Text */}
                    <div className="w-full md:w-1/2 p-8 text-white hidden md:block">
                        <Link to="/" className="inline-block mb-6">
                            <span className="self-center text-4xl font-bold whitespace-nowrap text-slate-100">Quantum<span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-sky-400">Leads</span></span>
                        </Link>
                        <h2 className="text-4xl font-bold leading-tight">
                            {view === 'login' && 'Your Gateway to Quality Leads'}
                            {view === 'register' && 'Start Your Growth Journey'}
                            {view === 'forgot' && 'Reset Your Password'}
                        </h2>
                        <p className="mt-4 text-lg text-slate-300">
                           {view === 'login' && 'Log in to manage your campaigns and connect with your next customers.'}
                           {view === 'register' && 'Register today and unlock a consistent stream of high-intent leads.'}
                           {view === 'forgot' && 'Enter your email below to receive a password reset link.'}
                        </p>
                    </div>

                    {/* Right Side Form */}
                    <div className="w-full md:w-1/2 p-8 rounded-2xl bg-zinc-800/50 backdrop-blur-md border border-zinc-700/50">
                        <div className="w-full max-w-sm mx-auto">
                             {view === 'forgot' ? (
                                <div key="forgot-form">
                                    <h3 className="text-2xl font-bold text-center text-white mb-2">Forgot Password?</h3>
                                    <p className="text-slate-400 text-center text-sm mb-6">No problem. We'll send you a reset link.</p>
                                    <form onSubmit={handleResetSubmit} className="space-y-6">
                                        <div className="relative">
                                            <label className="block text-sm font-medium text-slate-400 mb-2">Email Address</label>
                                            <div className="absolute inset-y-0 left-0 flex items-center pl-3.5 mt-8 pointer-events-none">
                                                <EmailIcon />
                                            </div>
                                            <input type="email" placeholder="you@example.com" className="w-full bg-zinc-700/50 border-zinc-600 rounded-lg py-3 pl-10 pr-4 text-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all duration-300 placeholder-slate-500" required />
                                        </div>
                                        <div>
                                            <button type="submit" className="w-full animate-gradient bg-gradient-to-r from-green-400 via-emerald-500 to-sky-600 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-300 shadow-lg shadow-emerald-500/20 transform hover:scale-105">
                                                Send Reset Link
                                            </button>
                                        </div>
                                        {resetStatus && <p className="text-center text-sm text-emerald-400 mt-4">{resetStatus}</p>}
                                    </form>
                                     <p className="text-center text-sm text-slate-400 mt-8">
                                        Remembered your password?{' '}
                                        <button onClick={() => setView('login')} className="font-semibold text-emerald-400 hover:underline">
                                           Back to Login
                                        </button>
                                    </p>
                                </div>
                            ) : (
                                <div key="auth-form">
                                    <div className="text-center mb-8 md:hidden">
                                        <Link to="/" className="inline-block">
                                            <span className="self-center text-3xl font-bold whitespace-nowrap text-slate-100">Quantum<span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-sky-400">Leads</span></span>
                                        </Link>
                                    </div>

                                    <div className="flex border-b border-zinc-700 mb-6">
                                        <button
                                            onClick={() => setView('login')}
                                            className={`flex-1 py-3 text-sm font-semibold transition-colors duration-300 focus:outline-none ${activeTab === 'login' ? 'text-white border-b-2 border-emerald-500' : 'text-slate-400 hover:text-white'}`}
                                        >
                                            Log In
                                        </button>
                                        <button
                                            onClick={() => setView('register')}
                                            className={`flex-1 py-3 text-sm font-semibold transition-colors duration-300 focus:outline-none ${activeTab === 'register' ? 'text-white border-b-2 border-emerald-500' : 'text-slate-400 hover:text-white'}`}
                                        >
                                            Register
                                        </button>
                                    </div>

                                    <form className="space-y-6">
                                        {view === 'register' && (
                                            <div className="relative">
                                                <label className="block text-sm font-medium text-slate-400 mb-2">Full Name</label>
                                                <div className="absolute inset-y-0 left-0 flex items-center pl-3.5 mt-8 pointer-events-none">
                                                    <UserIcon />
                                                </div>
                                                <input type="text" placeholder="John Doe" className="w-full bg-zinc-700/50 border-zinc-600 rounded-lg py-3 pl-10 pr-4 text-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all duration-300 placeholder-slate-500" />
                                            </div>
                                        )}
                                        <div className="relative">
                                            <label className="block text-sm font-medium text-slate-400 mb-2">Email Address</label>
                                            <div className="absolute inset-y-0 left-0 flex items-center pl-3.5 mt-8 pointer-events-none">
                                                <EmailIcon />
                                            </div>
                                            <input type="email" placeholder="you@example.com" className="w-full bg-zinc-700/50 border-zinc-600 rounded-lg py-3 pl-10 pr-4 text-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all duration-300 placeholder-slate-500" />
                                        </div>

                                        <div className="relative">
                                            <label className="block text-sm font-medium text-slate-400 mb-2">Password</label>
                                            <div className="absolute inset-y-0 left-0 flex items-center pl-3.5 mt-8 pointer-events-none">
                                                <LockIcon />
                                            </div>
                                            <input type={showPassword ? "text" : "password"} placeholder="••••••••" className="w-full bg-zinc-700/50 border-zinc-600 rounded-lg py-3 pl-10 pr-10 text-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all duration-300 placeholder-slate-500" />
                                            <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 flex items-center pr-3 mt-8 group" aria-label={showPassword ? 'Hide password' : 'Show password'}>
                                                {showPassword ? <EyeSlashIcon /> : <EyeIcon />}
                                            </button>
                                        </div>
                                        
                                        {view === 'register' && (
                                            <div className="relative">
                                                <label className="block text-sm font-medium text-slate-400 mb-2">Retype Password</label>
                                                <div className="absolute inset-y-0 left-0 flex items-center pl-3.5 mt-8 pointer-events-none">
                                                    <LockIcon />
                                                </div>
                                                <input type={showRetypePassword ? "text" : "password"} placeholder="••••••••" className="w-full bg-zinc-700/50 border-zinc-600 rounded-lg py-3 pl-10 pr-10 text-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all duration-300 placeholder-slate-500" />
                                                <button type="button" onClick={() => setShowRetypePassword(!showRetypePassword)} className="absolute inset-y-0 right-0 flex items-center pr-3 mt-8 group" aria-label={showRetypePassword ? 'Hide password' : 'Show password'}>
                                                    {showRetypePassword ? <EyeSlashIcon /> : <EyeIcon />}
                                                </button>
                                            </div>
                                        )}

                                        {view === 'login' && (
                                            <div className="flex items-center justify-end">
                                                <button type="button" onClick={() => setView('forgot')} className="text-sm text-emerald-400 hover:underline">Forgot your password?</button>
                                            </div>
                                        )}

                                        <div>
                                            <button type="submit" className="w-full animate-gradient bg-gradient-to-r from-green-400 via-emerald-500 to-sky-600 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-300 shadow-lg shadow-emerald-500/20 transform hover:scale-105">
                                                {view === 'login' ? 'Log In' : 'Create Account'}
                                            </button>
                                        </div>
                                    </form>

                                    <p className="text-center text-sm text-slate-400 mt-8">
                                        {view === 'login' ? "Don't have an account? " : "Already have an account? "}
                                        <button onClick={() => setView(view === 'login' ? 'register' : 'login')} className="font-semibold text-emerald-400 hover:underline">
                                        {view === 'login' ? 'Register' : 'Log In'}
                                        </button>
                                    </p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LoginPage;