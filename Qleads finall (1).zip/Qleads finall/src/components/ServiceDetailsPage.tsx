
import React, { useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';

// Reusable component for scroll animations
interface AnimateOnScrollProps {
    children: React.ReactNode;
    className?: string;
    animation?: 'fade-in-up' | 'fade-in-down' | 'fade-in-left' | 'fade-in-right' | 'zoom-in';
    delay?: number;
    as?: React.ElementType;
    id?: string;
}

const AnimateOnScroll: React.FC<AnimateOnScrollProps> = ({
    children,
    className = '',
    animation = 'fade-in-up',
    delay = 0,
    as: Tag = 'div',
    id,
}) => {
    const ref = useRef<HTMLElement>(null);
    const [isVisible, setIsVisible] = React.useState(false);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    setIsVisible(true);
                    observer.unobserve(entry.target);
                }
            },
            { threshold: 0.1 }
        );

        const currentRef = ref.current;
        if (currentRef) {
            observer.observe(currentRef);
        }

        return () => {
            if (currentRef) {
                observer.unobserve(currentRef);
            }
        };
    }, []);

    const combinedClassName = `scroll-animate ${animation} ${isVisible ? 'is-visible' : ''} ${className}`;

    return (
        <Tag
            id={id}
            ref={ref}
            className={combinedClassName}
            style={{ transitionDelay: `${delay}ms` }}
        >
            {children}
        </Tag>
    );
};

const PageHeader = ({ title, subtitle }: { title: string, subtitle: string }) => (
    <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-extrabold text-slate-100 mb-3">{title}</h1>
        <p className="text-lg text-slate-400">{subtitle}</p>
        <div className="mt-4 h-1 w-24 bg-gradient-to-r from-emerald-500 to-sky-400 mx-auto rounded-full"></div>
    </div>
);

const ServiceDetailSection = ({ icon, title, children }: { icon: React.ReactNode, title: string, children: React.ReactNode }) => {
    return (
        <div className="bg-zinc-800/50 backdrop-blur-lg border border-zinc-700/50 rounded-xl p-8 shadow-lg transition-all duration-300 hover:border-emerald-400/50 hover:shadow-2xl hover:shadow-emerald-400/30">
            <div className="flex items-start space-x-4">
                 <div className="flex-shrink-0 mt-1 w-12 h-12 rounded-lg bg-emerald-400/10 text-emerald-400 flex items-center justify-center border border-emerald-400/20">
                    {icon}
                </div>
                <div>
                    <h2 className="text-3xl font-bold text-slate-100 mb-4">{title}</h2>
                    <div className="text-slate-400 space-y-4 leading-relaxed">
                        {children}
                    </div>
                </div>
            </div>
        </div>
    );
};

const ServiceDetailsPage: React.FC = () => {
    const location = useLocation();

    useEffect(() => {
        if (location.hash) {
            const id = location.hash.substring(1);
            setTimeout(() => {
                const element = document.getElementById(id);
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }, 300); // Delay allows for page animations
        } else {
            window.scrollTo(0, 0);
        }
    }, [location]);

    return (
        <div className="py-12 container mx-auto px-4 md:px-8">
            <AnimateOnScroll>
                <PageHeader title="Our Services in Detail" subtitle="How We Fuel Your Growth Engine" />
            </AnimateOnScroll>

            <div className="max-w-4xl mx-auto space-y-12">
                <AnimateOnScroll id="inbound-calls" delay={100} animation="fade-in-right">
                    <ServiceDetailSection 
                        title="Inbound Calls – Connect with Real US Customers"
                        icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>}
                    >
                        <h3 className="text-xl font-semibold text-slate-200 mb-2">What is this?</h3>
                        <p>Our inbound call service connects you directly with pre-qualified, high-intent US customers who are actively searching for your products or services. Unlike cold calling, these are genuine prospects already interested in what you offer.</p>
                        
                        <h3 className="text-xl font-semibold text-slate-200 mb-3 mt-6">How it Works</h3>
                        <ol className="space-y-2">
                           <li className="flex items-center"><span className="flex-shrink-0 w-6 h-6 bg-zinc-700 text-emerald-400 rounded-full text-sm flex items-center justify-center mr-3 font-bold">1</span> Customers search for your product/service.</li>
                           <li className="flex items-center"><span className="flex-shrink-0 w-6 h-6 bg-zinc-700 text-emerald-400 rounded-full text-sm flex items-center justify-center mr-3 font-bold">2</span> We verify and qualify their intent.</li>
                           <li className="flex items-center"><span className="flex-shrink-0 w-6 h-6 bg-zinc-700 text-emerald-400 rounded-full text-sm flex items-center justify-center mr-3 font-bold">3</span> Calls are instantly routed to your sales team in real time.</li>
                        </ol>

                        <h3 className="text-xl font-semibold text-slate-200 mb-3 mt-6">Key Benefits</h3>
                        <ul className="list-disc list-inside space-y-2 pl-2">
                            <li><strong>High Purchase Intent</strong> – Speak only with motivated buyers ready to convert.</li>
                            <li><strong>Real-Time Delivery</strong> – No delays, calls connect instantly to maximize conversion.</li>
                            <li><strong>Quality Assurance</strong> – Every call is monitored and verified to meet strict quality standards.</li>
                            <li><strong>Exclusive Calls</strong> – All calls are generated only for your business (never resold).</li>
                        </ul>
                        <div className="mt-8">
                            <Link to="/contact">
                                <button className="animate-gradient bg-gradient-to-r from-green-400 via-emerald-500 to-sky-600 text-white font-semibold py-2 px-6 rounded-lg transition-all duration-300 shadow-lg shadow-emerald-500/20 transform hover:scale-105">
                                    Book Now
                                </button>
                            </Link>
                        </div>
                    </ServiceDetailSection>
                </AnimateOnScroll>

                <AnimateOnScroll id="exclusive-leads" delay={200} animation="fade-in-left">
                     <ServiceDetailSection
                        title="Exclusive Leads – 100% Yours, No Reselling"
                        icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 016-6h6a6 6 0 016 6v1h-3M15 21a2 2 0 002-2v-1a2 2 0 00-2-2h-3.372a2 2 0 00-1.263.459L12 15l-1.365-1.541a2 2 0 00-1.263-.459H6a2 2 0 00-2 2v1a2 2 0 002 2h9zm-3-9a4 4 0 000-8 4 4 0 000 8z" /></svg>}
                     >
                        <h3 className="text-xl font-semibold text-slate-200 mb-2">What is this?</h3>
                        <p>Our Exclusive Leads service ensures that every lead we generate belongs only to your business. We never resell or share your leads with competitors, giving you complete ownership and higher chances of conversion.</p>
                        
                        <h3 className="text-xl font-semibold text-slate-200 mb-3 mt-6">How it Works</h3>
                        <ol className="space-y-2">
                           <li className="flex items-center"><span className="flex-shrink-0 w-6 h-6 bg-zinc-700 text-emerald-400 rounded-full text-sm flex items-center justify-center mr-3 font-bold">1</span> Leads are generated through targeted campaigns.</li>
                           <li className="flex items-center"><span className="flex-shrink-0 w-6 h-6 bg-zinc-700 text-emerald-400 rounded-full text-sm flex items-center justify-center mr-3 font-bold">2</span> Every lead is verified for authenticity and intent.</li>
                           <li className="flex items-center"><span className="flex-shrink-0 w-6 h-6 bg-zinc-700 text-emerald-400 rounded-full text-sm flex items-center justify-center mr-3 font-bold">3</span> Delivered exclusively to you — no one else gets them.</li>
                        </ol>

                        <h3 className="text-xl font-semibold text-slate-200 mb-3 mt-6">Key Benefits</h3>
                        <ul className="list-disc list-inside space-y-2 pl-2">
                            <li><strong>No Reselling</strong> – Your leads are private and 100% exclusive.</li>
                            <li><strong>Higher Conversion Rates</strong> – Being the only contact gives you a strong advantage.</li>
                            <li><strong>Brand Integrity</strong> – Avoid customer frustration caused by multiple providers calling the same lead.</li>
                            <li><strong>Long-Term Value</strong> – Exclusive leads help you build a sustainable, loyal customer base.</li>
                        </ul>
                         <div className="mt-8">
                            <Link to="/contact">
                                <button className="animate-gradient bg-gradient-to-r from-green-400 via-emerald-500 to-sky-600 text-white font-semibold py-2 px-6 rounded-lg transition-all duration-300 shadow-lg shadow-emerald-500/20 transform hover:scale-105">
                                    Book Now
                                </button>
                            </Link>
                        </div>
                    </ServiceDetailSection>
                </AnimateOnScroll>

                <AnimateOnScroll id="pay-per-lead-campaigns" delay={300} animation="fade-in-right">
                     <ServiceDetailSection
                        title="Pay Per Lead Campaigns – Risk-Free, Performance-Based"
                        icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" /></svg>}
                     >
                        <h3 className="text-xl font-semibold text-slate-200 mb-2">What is this?</h3>
                        <p>Our Pay Per Lead (PPL) model ensures you only pay for verified, high-quality leads delivered directly to your business. With no upfront costs or long-term commitments, this model gives you complete control and maximum ROI.</p>

                        <h3 className="text-xl font-semibold text-slate-200 mb-3 mt-6">How it Works</h3>
                        <ol className="space-y-2">
                           <li className="flex items-center"><span className="flex-shrink-0 w-6 h-6 bg-zinc-700 text-emerald-400 rounded-full text-sm flex items-center justify-center mr-3 font-bold">1</span> We run targeted campaigns to attract your ideal customers.</li>
                           <li className="flex items-center"><span className="flex-shrink-0 w-6 h-6 bg-zinc-700 text-emerald-400 rounded-full text-sm flex items-center justify-center mr-3 font-bold">2</span> Every lead is verified for accuracy and intent.</li>
                           <li className="flex items-center"><span className="flex-shrink-0 w-6 h-6 bg-zinc-700 text-emerald-400 rounded-full text-sm flex items-center justify-center mr-3 font-bold">3</span> You only pay for the leads you receive – nothing else.</li>
                        </ol>

                        <h3 className="text-xl font-semibold text-slate-200 mb-3 mt-6">Key Benefits</h3>
                        <ul className="list-disc list-inside space-y-2 pl-2">
                            <li><strong>Risk-Free Marketing</strong> – No hidden costs, pay only for actual leads.</li>
                            <li><strong>Transparent Pricing</strong> – Clear cost-per-lead for easy budgeting.</li>
                            <li><strong>Scalable Growth</strong> – Increase or decrease lead flow as per your business needs.</li>
                            <li><strong>High ROI</strong> – Pay only for results that matter.</li>
                        </ul>
                         <div className="mt-8">
                            <Link to="/contact">
                                <button className="animate-gradient bg-gradient-to-r from-green-400 via-emerald-500 to-sky-600 text-white font-semibold py-2 px-6 rounded-lg transition-all duration-300 shadow-lg shadow-emerald-500/20 transform hover:scale-105">
                                    Book Now
                                </button>
                            </Link>
                        </div>
                    </ServiceDetailSection>
                </AnimateOnScroll>

                <AnimateOnScroll id="custom-campaigns" delay={400} animation="fade-in-left">
                     <ServiceDetailSection
                        title="Custom Campaigns – Tailored for Your Business"
                        icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0 3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>}
                     >
                        <h3 className="text-xl font-semibold text-slate-200 mb-2">What is this?</h3>
                        <p>Every business is unique, and so are its customers. Our Custom Campaigns are designed specifically for your industry, audience, and growth goals. From strategy to execution, we create a fully personalized lead generation plan.</p>
                        
                        <h3 className="text-xl font-semibold text-slate-200 mb-3 mt-6">How it Works</h3>
                        <ol className="space-y-2">
                           <li className="flex items-center"><span className="flex-shrink-0 w-6 h-6 bg-zinc-700 text-emerald-400 rounded-full text-sm flex items-center justify-center mr-3 font-bold">1</span> We analyze your business, industry, and target audience.</li>
                           <li className="flex items-center"><span className="flex-shrink-0 w-6 h-6 bg-zinc-700 text-emerald-400 rounded-full text-sm flex items-center justify-center mr-3 font-bold">2</span> A bespoke strategy is created with multi-channel marketing.</li>
                           <li className="flex items-center"><span className="flex-shrink-0 w-6 h-6 bg-zinc-700 text-emerald-400 rounded-full text-sm flex items-center justify-center mr-3 font-bold">3</span> Campaigns are continuously monitored and optimized for results.</li>
                        </ol>

                        <h3 className="text-xl font-semibold text-slate-200 mb-3 mt-6">Key Benefits</h3>
                        <ul className="list-disc list-inside space-y-2 pl-2">
                            <li><strong>Bespoke Strategy</strong> – Solutions tailored to your exact business needs.</li>
                            <li><strong>Multi-Channel Approach</strong> – PPC, social media, SEO, content marketing & more.</li>
                            <li><strong>Continuous Optimization</strong> – Real-time adjustments for peak performance.</li>
                            <li><strong>Sustainable Growth</strong> – Long-term campaigns that build your brand and pipeline.</li>
                        </ul>
                         <div className="mt-8">
                            <Link to="/contact">
                                <button className="animate-gradient bg-gradient-to-r from-green-400 via-emerald-500 to-sky-600 text-white font-semibold py-2 px-6 rounded-lg transition-all duration-300 shadow-lg shadow-emerald-500/20 transform hover:scale-105">
                                    Book Now
                                </button>
                            </Link>
                        </div>
                    </ServiceDetailSection>
                </AnimateOnScroll>
            </div>
        </div>
    );
};

export default ServiceDetailsPage;