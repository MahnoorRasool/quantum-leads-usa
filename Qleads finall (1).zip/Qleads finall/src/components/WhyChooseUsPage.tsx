
import React, { useState, useEffect, useRef } from 'react';

interface AnimateOnScrollProps {
    children: React.ReactNode;
    className?: string;
    animation?: 'fade-in-up' | 'fade-in-down' | 'fade-in-left' | 'fade-in-right' | 'zoom-in';
    delay?: number;
    as?: React.ElementType;
}

const AnimateOnScroll: React.FC<AnimateOnScrollProps> = ({
    children,
    className = '',
    animation = 'fade-in-up',
    delay = 0,
    as: Tag = 'div',
}) => {
    const ref = useRef<HTMLElement>(null);
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    setIsVisible(true);
                    observer.unobserve(entry.target);
                }
            },
            { threshold: 0.1 }
        );

        const currentRef = ref.current;
        if (currentRef) {
            observer.observe(currentRef);
        }

        return () => {
            if (currentRef) {
                observer.unobserve(currentRef);
            }
        };
    }, []);

    const combinedClassName = `scroll-animate ${animation} ${isVisible ? 'is-visible' : ''} ${className}`;

    return (
        <Tag
            ref={ref}
            className={combinedClassName}
            style={{ transitionDelay: `${delay}ms` }}
        >
            {children}
        </Tag>
    );
};

const PageHeader = ({ title, subtitle }: { title: string, subtitle: string }) => (
    <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-extrabold text-slate-100 mb-3">{title}</h1>
        <p className="text-lg text-slate-400">{subtitle}</p>
        <div className="mt-4 h-1 w-24 bg-gradient-to-r from-emerald-500 to-sky-400 mx-auto rounded-full"></div>
    </div>
);

const BenefitCard = ({ icon, title, subtitle, description }: { icon: React.ReactNode, title: string, subtitle: string, description: string }) => (
    <div className="bg-zinc-800/40 backdrop-blur-md border border-zinc-700/60 rounded-xl p-6 shadow-lg shadow-black/20 transition-all duration-300 hover:border-emerald-400/50 hover:bg-zinc-800/60 hover:-translate-y-1 hover:shadow-2xl hover:shadow-emerald-400/30 h-full flex">
        <div className="flex items-start space-x-5">
            <div className="flex-shrink-0 mt-1 w-12 h-12 rounded-lg bg-emerald-400/10 text-emerald-400 flex items-center justify-center border border-emerald-400/20">
                {icon}
            </div>
            <div>
                <h3 className="text-lg font-semibold text-slate-100">{title}</h3>
                <p className="text-sm font-medium text-emerald-400">{subtitle}</p>
                <p className="text-slate-400 mt-3 text-sm leading-relaxed">{description}</p>
            </div>
        </div>
    </div>
);


const WhyChooseUsPage: React.FC = () => {
    const benefits = [
        {
            icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>,
            title: 'UK Registered Company',
            subtitle: 'Legally Secure Partnership',
            description: 'Full legal compliance and business registration in the UK, ensuring secure and trustworthy partnerships.'
        },
        {
            icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>,
            title: '100% Targeted US Leads',
            subtitle: 'Precision Targeting',
            description: 'Every lead is specifically targeted to the US market with verified location and demographic data.'
        },
        {
            icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V7a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>,
            title: 'Transparent Reporting',
            subtitle: 'Real-time Analytics',
            description: 'Comprehensive dashboards and reports showing lead performance, conversion rates, and ROI metrics.'
        },
        {
            icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
            title: '24/7 Support',
            subtitle: 'Always Available',
            description: 'Round-the-clock customer support with dedicated account managers for immediate assistance.'
        },
    ];

    return (
        <div className="py-12 container mx-auto px-4 md:px-8">
            <div className="bg-zinc-800 border border-zinc-700/60 rounded-2xl p-8 md:p-12">
                <AnimateOnScroll>
                    <PageHeader title="Why Choose Us?" subtitle="Your Trusted Partner for Growth" />
                </AnimateOnScroll>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
                    <AnimateOnScroll animation="fade-in-left" delay={100}>
                        <div className="p-2 bg-zinc-700/40 rounded-2xl shadow-lg shadow-black/30 border border-zinc-700/50">
                             <img 
                                src="https://media.istockphoto.com/id/1146098091/photo/three-colleagues-talking-about-their-new-business-plan-in-the-office.jpg?s=612x612&w=0&k=20&c=dOLSP98UbWpfm58ZDEiPW9pktoDRojoozCFSNCgZNc0=" 
                                alt="Business team planning their growth strategy" 
                                className="rounded-xl w-full h-full object-cover"
                             />
                        </div>
                    </AnimateOnScroll>
                     <AnimateOnScroll animation="fade-in-right" delay={200}>
                        <p className="text-lg text-slate-400 text-center lg:text-left">
                            Choosing the right partner for lead generation can make all the difference in your business growth. With our proven expertise, legally registered operations, and dedicated team, we ensure you get high-quality, targeted leads that deliver real results. We focus on transparency, trust, and consistent performance — so you can focus on closing deals while we handle the lead flow.
                        </p>
                    </AnimateOnScroll>
                </div>


                <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
                    {benefits.map((benefit, index) => (
                        <AnimateOnScroll key={benefit.title} delay={(index * 100) + 200} animation="zoom-in" className="h-full">
                            <BenefitCard {...benefit} />
                        </AnimateOnScroll>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default WhyChooseUsPage;